package com.dummy.data.InsuranceData;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.fluttercode.datafactory.impl.DataFactory;

import au.com.bytecode.opencsv.CSVWriter;

public class LogGenerator {
 
		static final long unixTime = System.currentTimeMillis() / 1000L;
   		static String[] userAgent={ "Mozilla/5.0" , "Windows NT 6.2; rv:20.0 " , "Gecko/20121202" , "Firefox/20.0"};
		static DataFactory df = new DataFactory();
		static int flag = 0;

		public static void createDirectoryIfNeeded(String directoryName) {
			File theDir = new File(directoryName);
			// if the directory does not exist, create it
			if (!theDir.exists() && !theDir.isDirectory()) {
				theDir.mkdirs();
			}
		}

		public static void generateInformation(String saveDir, int row) throws IOException {

			// String saveDir="/home/abhinandan/Desktop/dump";
			createDirectoryIfNeeded(saveDir);
			String filePath = saveDir + "/Sessionlog.csv";
			CSVWriter writer = new CSVWriter(new FileWriter(filePath), CSVWriter.DEFAULT_SEPARATOR,
					CSVWriter.NO_QUOTE_CHARACTER);
			String clientInfoHeader = "LogType,SessionId,UserId,StartTimeStamp,EndTimeStamp,PageId,Page_SessionId,IPAddress,UserAgent,TotalTimeSpend";
			writer.writeNext(clientInfoHeader.split(","));
			writer.flush();

			 
			
			 
			for (int i = 0; i < row; i++) {
				String LogType = "webaccess";  
				String SessionId =  String.valueOf((df.getNumberBetween(100, 999))) + df.getRandomChar() + String.valueOf((df.getNumberBetween(10, 99)))+ df.getRandomChar()+String.valueOf((df.getNumberBetween(10, 99)));
				String UserId = String.valueOf((df.getNumberBetween(100000000, 999999999))) ;
				long StartTimeStamp = System.currentTimeMillis();
				
				String PageId = String.valueOf((df.getNumberBetween(10000, 99999)));
				String Page_SessionId = String.valueOf((df.getNumberBetween(100, 999))) + df.getRandomChar() + String.valueOf((df.getNumberBetween(10, 99)))+ df.getRandomChar()+String.valueOf((df.getNumberBetween(10, 99)));

				Random r = new Random();
				String IPAddress =  r.nextInt(256) + "." + r.nextInt(256) + "." + r.nextInt(256) + "." + r.nextInt(256);
 
				String UserAgent = userAgent[ df.getNumberBetween(0, 4)];
				long EndTimeStampPageId = System.currentTimeMillis() + (df.getNumberBetween(1000000, 9999999));
				long TotalTimeSpend=  EndTimeStampPageId - StartTimeStamp;
 				String csvRow = LogType + "," + SessionId + "," + UserId + "," + StartTimeStamp + "," + EndTimeStampPageId  + "," + PageId + "," + Page_SessionId + ","
						+ IPAddress + "," + UserAgent + "," + TotalTimeSpend   ;
 				
 				
 				
 				
				writer.writeNext(csvRow.split(","));
				 
				writer.flush();
			}

			writer.close();
			 
		}

	 
		 
		public static void main(String[] args) throws IOException {
			/*
			 * if (args.length < 2) { System.out.println(
			 * "Please enter <Destination Location> <No no Line>"); } else { String
			 * destLocation = args[0]; int row = Integer.parseInt(args[1]);
			 * generateClientInformation(destLocation, row); }
			 */

			generateInformation("C:/Users/abistat/Desktop/assets", 10);
		}

 

}
